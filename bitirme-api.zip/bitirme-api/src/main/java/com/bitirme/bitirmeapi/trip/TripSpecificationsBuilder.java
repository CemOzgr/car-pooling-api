package com.bitirme.bitirmeapi.trip;

import com.bitirme.bitirmeapi.util.SearchCriteria;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class TripSpecificationsBuilder {
    private final List<SearchCriteria> params;

    public TripSpecificationsBuilder() {
        this.params = new ArrayList<>();
    }

    public TripSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }

    public Specification<Trip> build() {
        if(params.isEmpty()) {
            return null;
        }
        List<Specification<Trip>> specs = params
                .stream()
                .map(TripSpecification::new)
                .collect(Collectors.toList());

        Specification<Trip> result = specs.get(0);

        for(int i=1; i<params.size(); i++) {
            result = Specification.where(result).and(specs.get(i));

        }
        return result;
    }

}
