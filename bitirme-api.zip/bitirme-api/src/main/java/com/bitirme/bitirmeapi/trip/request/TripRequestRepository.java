package com.bitirme.bitirmeapi.trip.request;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TripRequestRepository extends JpaRepository<TripRequest, Integer> {

    @EntityGraph("trip-request-graph")
    @Query("SELECT r FROM TripRequest r WHERE r.submitter.id = ?1")
    List<TripRequest> findBySubmitter(int submitterId);

    @EntityGraph("submitter-request-graph")
    @Query("SELECT r FROM TripRequest r WHERE r.trip.id = ?1")
    List<TripRequest> findByTrip(int tripId);

    @Query("SELECT CASE WHEN COUNT(r) > 0 THEN true ELSE false END " +
            "FROM TripRequest r " +
            "WHERE r.trip.id =?1 AND r.submitter.id =?2 AND r.status = 'ACCEPTED'")
    boolean isRequestPreviouslyApproved(int tripId, int submitterId);

    @EntityGraph("submitter-request-graph")
    @Query("SELECT r FROM TripRequest r WHERE r.trip.id = ?1 AND r.status='ACCEPTED'")
    List<TripRequest> findApprovedByTrip(int tripId);

}
