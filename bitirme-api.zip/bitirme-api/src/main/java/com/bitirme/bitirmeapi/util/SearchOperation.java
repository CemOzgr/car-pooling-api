package com.bitirme.bitirmeapi.util;public enum SearchOperation {
}
