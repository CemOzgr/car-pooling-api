package com.bitirme.bitirmeapi.member.preferences;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PreferencesDto {

    private boolean smokingAllowed;
    private boolean petsAllowed;
    private String musicPreference;
    private String conversationPreference;

    public PreferencesDto(Preference preference) {
        this.smokingAllowed = preference.isSmokingAllowed();
        this.petsAllowed = preference.isPetsAllowed();
        this.musicPreference = preference.getMusic().getDescription();
        this.conversationPreference = preference.getConversation().getDescription();
    }

}
