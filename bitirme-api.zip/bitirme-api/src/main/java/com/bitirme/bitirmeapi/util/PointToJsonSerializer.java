package com.bitirme.bitirmeapi.util;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.vividsolutions.jts.geom.Point;

import java.io.IOException;

public class PointToJsonSerializer extends JsonSerializer<Point> {

    @Override
    public void serialize(Point point,
                          JsonGenerator jsonGenerator,
                          SerializerProvider serializerProvider) throws IOException {
        String jsonValue = "null";
        try{
            if(point != null) {
                double lat = point.getX();
                double lon = point.getY();
                jsonValue = String.format("POINT (%s,%s)", lat, lon);
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        jsonGenerator.writeString(jsonValue);
    }
}
