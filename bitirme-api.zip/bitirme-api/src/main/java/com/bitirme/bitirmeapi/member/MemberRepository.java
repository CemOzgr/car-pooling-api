package com.bitirme.bitirmeapi.member;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

public interface MemberRepository extends JpaRepository<Member, Integer> {

    @Transactional
    @Query("SELECT m from Member m JOIN FETCH m.ratings WHERE m.id = ?1")
    Optional<Member> findDetailed(Integer memberId);

    @Transactional
    @Query("SELECT m FROM Member m WHERE m.email = ?1")
    Optional<Member> findByEmail(String email);

    @Transactional
    @Modifying
    @Query("UPDATE Member m SET m.enabled=TRUE WHERE m.id = ?1")
    void enableMember(int id);
}
