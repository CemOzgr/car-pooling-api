package com.bitirme.bitirmeapi.trip.request;

import com.bitirme.bitirmeapi.member.Member;
import com.bitirme.bitirmeapi.trip.Trip;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TripRequestService {
    private final TripRequestRepository requestRepository;

    @Autowired
    public TripRequestService(TripRequestRepository requestRepository) {
        this.requestRepository = requestRepository;
    }

    public void createTripRequest(Trip trip, Member submitter) {
        if(requestRepository.isRequestPreviouslyApproved(trip.getId(), submitter.getId())) {
            throw new IllegalStateException("Request already accepted");
        }
        TripRequest request = new TripRequest(trip, submitter);
        request.setStatus("SUBMITTED");
        requestRepository.save(request);
    }

    public List<TripRequest> loadRequestsForTrip(int tripId) {
        return requestRepository.findByTrip(tripId);
    }

    public List<TripRequest> loadRequestsOfMember(int memberId) {
        return requestRepository.findBySubmitter(memberId);
    }

    public List<TripRequest> loadApprovedRequestsForTrip(int tripId) {
        return requestRepository.findApprovedByTrip(tripId);
    }

    public void approveRequest(int requestId) {
        TripRequest request = requestRepository.findById(requestId)
                .orElseThrow(() -> new IllegalStateException("Request not found"));
        request.setStatus("ACCEPTED");
        requestRepository.save(request);
    }


}
