package com.bitirme.bitirmeapi.trip.city;

import com.bitirme.bitirmeapi.trip.Trip;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name="cities")
@Getter
@Setter
@NoArgsConstructor
public class City {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;

    String name;

    @OneToMany(mappedBy = "startCity")
    private Set<Trip> tripsStartingFrom;

    @OneToMany(mappedBy = "destinationCity")
    private Set<Trip> tripsEndAt;
}
