package com.bitirme.bitirmeapi.registration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/registration")
public class RegistrationResource {

    private final RegistrationService registrationService;

    @Autowired
    public RegistrationResource(RegistrationService registrationService) {
        this.registrationService = registrationService;
    }

    @PostMapping("")
    public HttpStatus register(@RequestBody RegistrationRequestDto requestDto) {
        registrationService.register(requestDto);
        return HttpStatus.CREATED;
    }

    @GetMapping("/confirm")
    public HttpStatus confirmToken(@RequestParam String token) {
        registrationService.confirmToken(token);
        return HttpStatus.OK;
    }


}
