package com.bitirme.bitirmeapi.email;

public interface EmailSender {
    void send(String to, String email);
}
