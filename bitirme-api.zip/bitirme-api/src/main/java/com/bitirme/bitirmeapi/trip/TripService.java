package com.bitirme.bitirmeapi.trip;

import com.bitirme.bitirmeapi.member.Member;
import com.bitirme.bitirmeapi.member.vehicle.Vehicle;
import com.bitirme.bitirmeapi.member.MemberService;
import com.bitirme.bitirmeapi.member.vehicle.VehicleService;
import com.bitirme.bitirmeapi.trip.request.TripRequestDto;
import com.bitirme.bitirmeapi.trip.city.City;
import com.bitirme.bitirmeapi.trip.request.TripRequest;
import com.bitirme.bitirmeapi.trip.city.CityRepository;
import com.bitirme.bitirmeapi.trip.request.TripRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class TripService {

    private final TripRepository tripRepository;
    private final CityRepository cityRepository;
    private final VehicleService vehicleService;
    private final MemberService memberService;
    private final TripRequestService requestService;

    @Autowired
    public TripService(TripRepository tripRepository, CityRepository cityRepository,
                       VehicleService vehicleService, MemberService memberService, TripRequestService requestService) {
        this.tripRepository = tripRepository;
        this.cityRepository = cityRepository;
        this.vehicleService = vehicleService;
        this.memberService = memberService;
        this.requestService = requestService;
    }

    @Transactional
    public void createTrip(TripDto tripDto) {
        Vehicle vehicle = vehicleService.loadVehicle(tripDto.getDriverId());

        City startCity = cityRepository.findByName(tripDto.getStartCity())
                .orElseThrow(() -> new IllegalStateException("Unable to find city"));
        City destinationCity = cityRepository.findByName(tripDto.getDestinationCity())
                .orElseThrow(() -> new IllegalStateException("Unable to find city"));

        Trip trip = new Trip();
        trip.setDriver(vehicle.getMember());
        trip.setStartCity(startCity);
        trip.setDestinationCity(destinationCity);
        trip.setStartDate(tripDto.getStartDate());
        trip.setEndDate(tripDto.getEndDate());
        trip.setStartLocation(tripDto.getStartLocation());
        trip.setDestinationLocation(tripDto.getDestinationLocation());

        tripRepository.save(trip);
    }

    public List<Trip> loadTrips(String search) {
        TripSpecificationsBuilder builder = new TripSpecificationsBuilder();
        Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)(\\w+?|\\d{4}-\\d{2}-\\d{2}),",Pattern.UNICODE_CHARACTER_CLASS);

        Matcher matcher = pattern.matcher(search + ",");

        while(matcher.find()) {

            builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
        }
        Specification<Trip> specification = builder.build();
        return tripRepository.findAll(specification);
    }

    public Trip loadTrip(int id) {
        return tripRepository.findById(id)
                .orElseThrow(() -> new IllegalStateException("resource not found"));
    }

    @Transactional
    public void insertRequestToTrip(TripRequestDto requestDto) {
        Trip trip = tripRepository.getOne(requestDto.getTripId());
        Member submitter = memberService.loadMember(requestDto.getSubmitterId());
        requestService.createTripRequest(trip, submitter);
    }

    public List<TripRequest> loadRequestsOfMember(int memberId) {
        return requestService.loadRequestsOfMember(memberId);
    }

    public List<TripRequest> loadRequestsForTrip(int tripId) {
        return requestService.loadRequestsForTrip(tripId);
    }

    public List<Member> loadPassengersForTrip(int tripId) {
        List<TripRequest> requests = requestService.loadApprovedRequestsForTrip(tripId);
        return requests
                .stream()
                .map(TripRequest::getSubmitter)
                .collect(Collectors.toList());

    }

}
