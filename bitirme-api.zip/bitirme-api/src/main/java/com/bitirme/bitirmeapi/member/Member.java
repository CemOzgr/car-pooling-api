package com.bitirme.bitirmeapi.member;

import com.bitirme.bitirmeapi.member.rating.Rating;
import com.bitirme.bitirmeapi.trip.Trip;
import com.bitirme.bitirmeapi.trip.request.TripRequest;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.Email;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name="members")
@Getter
@Setter
@NoArgsConstructor
public class Member {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;

    @Email(message = "Email should be valid")
    @Column(name = "email", unique = true)
    private String email;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "contact_no")
    private String contactNo;

    private String password;

    @Column(name = "is_admin", updatable = false)
    private boolean admin = false;

    private Boolean enabled = false;

    private Boolean locked = false;

    @Column(name = "created_at", insertable = false, updatable = false)
    private Date createdAt;

    @Transient
    private Double averageRating;

    @OneToMany(mappedBy = "member", cascade = {CascadeType.ALL})
    private Set<Rating> ratings = new HashSet<>();

    @OneToMany(mappedBy = "driver")
    private Set<Trip> trips = new HashSet<>();

    @OneToMany(mappedBy = "submitter")
    private Set<TripRequest> tripRequests;

    public Member(String email, String firstName, String lastName, String contactNo, String password) {
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.contactNo = contactNo;
        this.password = password;
    }

}
