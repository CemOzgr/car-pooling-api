package com.bitirme.bitirmeapi.trip;

import com.bitirme.bitirmeapi.util.JsonToPointDeserializer;
import com.bitirme.bitirmeapi.util.PointToJsonSerializer;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.vividsolutions.jts.geom.Geometry;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TripDto {

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Integer id;

    private Integer driverId;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yy hh:mm:ss")
    private LocalDateTime startDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yy hh:mm:ss")
    private LocalDateTime endDate;

    private String startCity;
    private String destinationCity;

    @JsonSerialize(using = PointToJsonSerializer.class)
    @JsonDeserialize(using = JsonToPointDeserializer.class)
    private Geometry startLocation;

    @JsonSerialize(using = PointToJsonSerializer.class)
    @JsonDeserialize(using = JsonToPointDeserializer.class)
    private Geometry destinationLocation;

    public TripDto(Trip trip) {
        this.id = trip.getId();
        this.driverId = trip.getDriverId();
        this.startDate = trip.getStartDate();
        this.endDate = trip.getEndDate();
        this.startCity = trip.getStartCity().getName();
        this.destinationCity = trip.getDestinationCity().getName();
        this.startLocation = trip.getStartLocation();
        this.destinationLocation = trip.getDestinationLocation();
    }

}
