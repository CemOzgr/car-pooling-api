package com.bitirme.bitirmeapi.member.vehicle;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VehicleDto {

    private String plate;
    private String make;
    private String model;
    private int modelYear;
    private int type;

    public VehicleDto(Vehicle vehicle) {
        this.plate = vehicle.getPlate();
        this.make = vehicle.getMake();
        this.model = vehicle.getModel();
        this.modelYear = vehicle.getModelYear();
        this.type = vehicle.getType();
    }

}
