package com.bitirme.bitirmeapi.member;

import com.bitirme.bitirmeapi.member.preferences.PreferencesDto;
import com.bitirme.bitirmeapi.member.vehicle.VehicleDto;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MemberDto {

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private int id;

    private String fullName;
    private String email;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String password;
    private String contactNo;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Double averageRating = -1.0;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yy hh:mm:ss")
    private Date createdAt;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private PreferencesDto preferences;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private VehicleDto vehicle;

    public MemberDto(Member member) {
        this.id = member.getId();
        this.fullName = String.format("%s %s", member.getFirstName(), member.getLastName());
        this.email = member.getEmail();
        this.contactNo = member.getContactNo();
        this.createdAt = member.getCreatedAt();
    }

}
