package com.bitirme.bitirmeapi.member.rating;

import com.bitirme.bitirmeapi.member.Member;
import com.bitirme.bitirmeapi.member.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

@Service
public class RatingService {
    private final RatingRepository ratingRepository;
    private final MemberService memberService;

    @Autowired
    public RatingService(RatingRepository ratingRepository, MemberService memberService) {
        this.ratingRepository = ratingRepository;
        this.memberService = memberService;
    }

    @PreAuthorize("#ratingDto.memberId != authentication.principal.id")
    public void saveRating(RatingDto ratingDto) {
        if(ratingDto.getRating() > 5 || ratingDto.getRating() < 0) {
            throw new IllegalStateException("Rating should be between 0 and 5");
        }

        Rating rating = ratingRepository
                .findByMemberIdAndSubmitterId(ratingDto.getMemberId(), ratingDto.getSubmitterId())
                .orElse(new Rating());

        if(rating.getId() == 0) {
            Member member = memberService.loadMember(ratingDto.getMemberId());
            rating.setRating(ratingDto.getRating());
            rating.setMember(member);
            rating.setSubmitterId(ratingDto.getSubmitterId());
            ratingRepository.save(rating);
        } else {
            ratingRepository.updateRating(rating.getId(), ratingDto.getRating());
        }
    }

    @PreAuthorize("#memberId != authentication.principal.id")
    public void deleteRating(int memberId, int submitterId) {
        Rating rating = ratingRepository.findByMemberIdAndSubmitterId(memberId, submitterId)
                .orElseThrow(() -> new IllegalStateException("rating not found"));
        ratingRepository.delete(rating);
    }

    public Double loadAverageRatingOfMember(int memberId) {
        return ratingRepository.findAverageRatingByMember(memberId);
    }



}
