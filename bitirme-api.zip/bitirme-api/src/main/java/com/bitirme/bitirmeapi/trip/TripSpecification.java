package com.bitirme.bitirmeapi.trip;

import com.bitirme.bitirmeapi.trip.Trip;
import com.bitirme.bitirmeapi.util.SearchCriteria;
import lombok.AllArgsConstructor;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@AllArgsConstructor
public class TripSpecification implements Specification<Trip> {
    private final SearchCriteria criteria;

    @Override
    public Predicate toPredicate(Root<Trip> root,
                                 CriteriaQuery<?> query,
                                 CriteriaBuilder builder) {
        if(criteria.getOperation().equalsIgnoreCase(">")) {
            if(criteria.isDate()) {
                LocalDate date = LocalDate.parse(criteria.getValue().toString());
                LocalDateTime dateTime = LocalDateTime.of(date, LocalTime.parse("00:00:00"));

                return builder.greaterThanOrEqualTo(
                        root.get(criteria.getKey()), dateTime
                );
            }
            return builder.greaterThanOrEqualTo(
                    root.get(criteria.getKey()), criteria.getValue().toString()
            );
        } else if(criteria.getOperation().equalsIgnoreCase("<")) {
            if(criteria.isDate()) {
                LocalDate date = LocalDate.parse(criteria.getValue().toString());
                LocalDateTime dateTime = LocalDateTime.of(date, LocalTime.parse("00:00:00"));
                return builder.lessThanOrEqualTo(
                        root.get(criteria.getKey()), dateTime
                );
            }
            return builder.lessThanOrEqualTo(
                    root.get(criteria.getKey()), criteria.getValue().toString()
            );
        } else if(criteria.getOperation().equalsIgnoreCase(":")) {
            if(criteria.isCity()) {
                return builder.equal(
                        root.get(criteria.getKey()).get("name"), criteria.getValue()
                );
            } else if(criteria.isDate()) {
                LocalDate date = LocalDate.parse(criteria.getValue().toString());
                LocalDateTime dateTime = LocalDateTime.of(date, LocalTime.parse("00:00:00"));

                return builder.between(
                        root.get(criteria.getKey()),
                        dateTime,
                        dateTime.plusHours(23).plusMinutes(59).plusSeconds(59)
                );
            }
            return builder.equal(
                    root.get(criteria.getKey()), criteria.getValue()
            );
        }
        return null;
    }
}
