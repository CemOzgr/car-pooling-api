package com.bitirme.bitirmeapi.trip.request;

import com.bitirme.bitirmeapi.member.MemberDto;
import com.bitirme.bitirmeapi.trip.TripDto;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TripRequestDto {

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private int id;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private int tripId;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private int submitterId;

    private String status;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yy hh:mm:ss")
    private Date submittedAt;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private MemberDto submitter;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private TripDto trip;

    public TripRequestDto(TripRequest request) {
        this.id = request.getId();
        this.tripId = request.getTrip().getId();
        this.status = request.getStatus();
        this.submittedAt = request.getSubmittedAt();
    }


}
