package com.bitirme.bitirmeapi.trip;

import com.bitirme.bitirmeapi.member.Member;
import com.bitirme.bitirmeapi.trip.city.City;
import com.bitirme.bitirmeapi.trip.request.TripRequest;
import com.vividsolutions.jts.geom.Geometry;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Set;

@Entity
@Table(name="trips")
@Getter
@Setter
@NoArgsConstructor
@NamedEntityGraph(
        name = "city-trip-graph",
        attributeNodes = {
                @NamedAttributeNode("startCity"),
                @NamedAttributeNode("destinationCity")
        }
)
public class Trip {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "starting_loc")
    private Geometry startLocation;

    @Column(name = "destination_loc")
    private Geometry destinationLocation;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "start_city_id", referencedColumnName = "id")
    private City startCity;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "destination_city_id", referencedColumnName = "id")
    private City destinationCity;

    @Column(name = "start_date", columnDefinition = "TIMESTAMP")
    private LocalDateTime startDate;

    @Column(name = "end_date", columnDefinition = "TIMESTAMP")
    private LocalDateTime endDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "driver_id", referencedColumnName = "id")
    private Member driver;

    @Column(name = "driver_id", insertable = false, updatable = false)
    private int driverId;

    @OneToMany(mappedBy = "trip")
    private Set<TripRequest> tripRequests;

}
