package com.bitirme.bitirmeapi.member;

import com.bitirme.bitirmeapi.member.preferences.Preference;
import com.bitirme.bitirmeapi.member.preferences.PreferenceService;
import com.bitirme.bitirmeapi.member.preferences.PreferencesDto;
import com.bitirme.bitirmeapi.registration.token.ConfirmationToken;
import com.bitirme.bitirmeapi.registration.token.ConfirmationTokenService;
import com.bitirme.bitirmeapi.security.MemberDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class MemberService implements UserDetailsService {

    private final MemberRepository memberRepository;
    private final BCryptPasswordEncoder passwordEncoder;
    private final ConfirmationTokenService tokenService;
    private final PreferenceService preferenceService;

    @Autowired
    public MemberService(MemberRepository memberRepository, BCryptPasswordEncoder passwordEncoder,
                         ConfirmationTokenService tokenService, PreferenceService preferenceService) {
        this.memberRepository = memberRepository;
        this.passwordEncoder = passwordEncoder;
        this.tokenService = tokenService;
        this.preferenceService = preferenceService;
    }

    public Member loadMember(int memberId) {
        return memberRepository.findById(memberId)
                .orElseThrow(() -> new IllegalStateException("Unable to find resource"));
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Member member = memberRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("Member not found"));
        return new MemberDetails(member);
    }

    public List<Member> loadMembers() {
        return memberRepository.findAll();
    }

    public String signUpUser(Member member) {
        Optional<Member> optionalMember = memberRepository.findByEmail(member.getEmail());

        if(optionalMember.isPresent()) {
            if(!optionalMember.get().getEnabled()) {
                ConfirmationToken confirmationToken = tokenService.generateRandomToken(member);
                tokenService.saveConfirmationToken(confirmationToken);
                return confirmationToken.getToken();
            }
            throw new IllegalStateException("email already taken");
        }

        String encodedPassword = passwordEncoder.encode(member.getPassword());
        member.setPassword(encodedPassword);

        memberRepository.save(member);

        ConfirmationToken confirmationToken = tokenService.generateRandomToken(member);
        tokenService.saveConfirmationToken(confirmationToken);

        return confirmationToken.getToken();
    }

    public void enableMember(int memberId) {
        memberRepository.enableMember(memberId);
    }

    @PreAuthorize("#memberId == authentication.principal.id")
    @Transactional
    public void savePreference(int memberId, PreferencesDto preferencesDto) {
        Member member = this.loadMember(memberId);
        preferenceService.savePreference(member, preferencesDto);
    }

    public Preference loadMemberPreferences(int memberId) {
        return preferenceService.loadPreferencesOfMember(memberId);
    }

}
