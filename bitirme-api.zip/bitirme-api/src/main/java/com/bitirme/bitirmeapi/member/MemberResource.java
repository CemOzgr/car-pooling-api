package com.bitirme.bitirmeapi.member;

import com.bitirme.bitirmeapi.member.preferences.Preference;
import com.bitirme.bitirmeapi.member.preferences.PreferencesDto;
import com.bitirme.bitirmeapi.member.rating.RatingDto;
import com.bitirme.bitirmeapi.member.rating.RatingService;
import com.bitirme.bitirmeapi.security.MemberDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/members")
public class MemberResource {
    private final MemberService memberService;
    private final RatingService ratingService;

    @Autowired
    public MemberResource(MemberService memberService, RatingService ratingService) {
        this.memberService = memberService;
        this.ratingService = ratingService;
    }

    @GetMapping("")
    public List<MemberDto> loadMembers() {
        List<Member> members = memberService.loadMembers();
        return members
                .stream()
                .map(MemberDto::new)
                .collect(Collectors.toList());
    }

    @GetMapping("/{memberId}")
    public MemberDto loadMemberBasic(@PathVariable int memberId) {
        Member member = memberService.loadMember(memberId);
        Double averageRating = ratingService.loadAverageRatingOfMember(memberId);
        MemberDto dto =  new MemberDto(member);
        dto.setAverageRating(averageRating);
        return dto;
    }
    @GetMapping("/{memberId}/preference")
    public PreferencesDto loadMemberPreferences(@PathVariable int memberId) {
        Preference preference = memberService.loadMemberPreferences(memberId);
        return new PreferencesDto(preference);
    }

    @PostMapping("/{memberId}/preference")
    public HttpStatus saveMemberPreferences(@PathVariable int memberId,
                                            @RequestBody PreferencesDto preferencesDto) {
        memberService.savePreference(memberId, preferencesDto);
        return HttpStatus.CREATED;
    }

    @PostMapping("/{memberId}/ratings")
    public HttpStatus addRatingToMember(@AuthenticationPrincipal MemberDetails submitter,
                                        @PathVariable int memberId,
                                        @RequestBody double rating) {
        RatingDto ratingDto = new RatingDto(memberId, submitter.getId(), rating);
        ratingService.saveRating(ratingDto);
        return HttpStatus.CREATED;
    }

    @DeleteMapping("/{memberId}/ratings")
    public HttpStatus deleteRatingFromMember(@AuthenticationPrincipal MemberDetails submitter,
                                             @PathVariable int memberId) {
        ratingService.deleteRating(memberId, submitter.getId());
        return HttpStatus.OK;
    }

}
