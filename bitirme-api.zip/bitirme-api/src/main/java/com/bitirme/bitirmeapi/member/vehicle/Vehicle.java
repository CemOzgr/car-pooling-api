package com.bitirme.bitirmeapi.member.vehicle;

import com.bitirme.bitirmeapi.member.Member;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name="vehicles")
@Getter
@Setter
@NoArgsConstructor
public class Vehicle {

    @Id
    @Column(name="member_id")
    private int memberId;

    private String plate;
    private String make;
    private String model;

    @Column(name = "model_year")
    private int modelYear;

    @Column(name = "vehicle_type")
    private int type;

    @OneToOne
    @MapsId
    @JoinColumn(name="member_id")
    private Member member;

}
