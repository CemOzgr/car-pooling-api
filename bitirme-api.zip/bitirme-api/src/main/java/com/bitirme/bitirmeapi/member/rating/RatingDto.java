package com.bitirme.bitirmeapi.member.rating;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RatingDto {

    private int memberId;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private int submitterId;

    private double rating;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private int count;

    public RatingDto(int memberId, int submitterId, double rating) {
        this.memberId = memberId;
        this.submitterId = submitterId;
        this.rating = rating;
    }
}
