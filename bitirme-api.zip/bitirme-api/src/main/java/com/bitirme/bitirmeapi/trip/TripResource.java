package com.bitirme.bitirmeapi.trip;

import com.bitirme.bitirmeapi.member.MemberDto;
import com.bitirme.bitirmeapi.trip.request.TripRequestDto;
import com.bitirme.bitirmeapi.trip.request.TripRequest;
import com.bitirme.bitirmeapi.trip.request.TripRequestService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("api/trips")
public class TripResource {

    private final TripService tripService;
    private final TripRequestService requestService;

    public TripResource(TripService tripService, TripRequestService requestService) {
        this.tripService = tripService;
        this.requestService = requestService;
    }

    @GetMapping("/{tripId}")
    public TripDto loadTrip(@PathVariable int tripId) {
        Trip trip = tripService.loadTrip(tripId);
        return new TripDto(trip);
    }

    @GetMapping("")
    public List<TripDto> loadTrips(@RequestParam String search) {
        List<Trip> trips = tripService.loadTrips(search);
        return trips
                .stream()
                .map(TripDto::new)
                .collect(Collectors.toList());
    }

    @PostMapping("")
    public HttpStatus createTrip(@RequestBody TripDto tripDto) {
        tripService.createTrip(tripDto);
        return HttpStatus.CREATED;
    }

    @PostMapping("/requests")
    public HttpStatus insertTripRequest(@RequestBody TripRequestDto requestDto) {
        tripService.insertRequestToTrip(requestDto);
        return HttpStatus.CREATED;
    }

    @PatchMapping("/requests/{requestId}")
    public HttpStatus approveRequest(@PathVariable int requestId) {
        requestService.approveRequest(requestId);
        return HttpStatus.CREATED;
    }

    @GetMapping("/requests")
    public List<TripRequestDto> loadRequests(@RequestParam int memberId) {
        List<TripRequestDto> requestDtos = new ArrayList<>();
        List<TripRequest> requests = tripService.loadRequestsOfMember(memberId);

        requests.forEach(request -> {
            TripRequestDto requestDto = new TripRequestDto(request);
            TripDto tripDto = new TripDto();
            requestDto.setTrip(tripDto);
            requestDto.getTrip().setStartDate(request.getTrip().getStartDate());
            requestDto.getTrip().setEndDate(request.getTrip().getEndDate());
            requestDto.getTrip().setStartCity(request.getTrip().getStartCity().getName());
            requestDto.getTrip().setDestinationCity(request.getTrip().getDestinationCity().getName());

            requestDtos.add(requestDto);
        });
        return requestDtos;
    }

    @GetMapping("/{tripId}/requests")
    public List<TripRequestDto> loadRequestsForTrip(@PathVariable int tripId) {

        return tripService.loadRequestsForTrip(tripId)
                .stream()
                .map(request -> {
                    MemberDto submitter = new MemberDto();
                    submitter.setId(request.getSubmitter().getId());
                    submitter.setFullName(String.format("%s %s",
                            request.getSubmitter().getFirstName(),
                            request.getSubmitter().getLastName())
                    );
                    TripRequestDto requestDto = new TripRequestDto(request);
                    requestDto.setSubmitter(submitter);
                    return requestDto;
                })
                .collect(Collectors.toList());
    }

    @GetMapping("/{tripId}/passengers")
    public List<MemberDto> loadPassengersForTrip(@PathVariable int tripId) {

        return tripService.loadPassengersForTrip(tripId)
                .stream()
                .map(MemberDto::new)
                .collect(Collectors.toList());
    }

}
