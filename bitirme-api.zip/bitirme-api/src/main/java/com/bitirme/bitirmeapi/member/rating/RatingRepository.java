package com.bitirme.bitirmeapi.member.rating;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

public interface RatingRepository extends JpaRepository<Rating, Integer> {

    @Query("SELECT r FROM Rating r WHERE r.member.id = ?1 AND r.submitterId = ?2 ")
    Optional<Rating> findByMemberIdAndSubmitterId(int memberId, int submitterId);

    @Query("SELECT AVG(r.rating) FROM Rating r WHERE r.member.id = ?1 ")
    Double findAverageRatingByMember(int memberId);

    @Transactional
    @Modifying
    @Query("UPDATE Rating r SET r.rating = ?2 WHERE r.id= ?1 ")
    void updateRating(int id, double rating);

}
