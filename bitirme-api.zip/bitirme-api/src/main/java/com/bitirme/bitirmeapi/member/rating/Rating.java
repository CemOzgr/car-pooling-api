package com.bitirme.bitirmeapi.member.rating;

import com.bitirme.bitirmeapi.member.Member;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name="member_ratings")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Rating {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    @JoinColumn(name = "member_id", referencedColumnName = "id")
    private Member member;

    @Column(name = "submitter_id")
    private int submitterId;

    private double rating;

    public Rating(int submitterId, double rating) {
        this.submitterId = submitterId;
        this.rating = rating;
    }
}
