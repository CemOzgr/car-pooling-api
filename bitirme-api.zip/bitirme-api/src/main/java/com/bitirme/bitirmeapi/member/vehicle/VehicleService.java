package com.bitirme.bitirmeapi.member.vehicle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VehicleService {

    private final VehicleRepository vehicleRepository;

    @Autowired
    public VehicleService(VehicleRepository vehicleRepository) {
        this.vehicleRepository = vehicleRepository;
    }

    public Vehicle loadVehicle(int memberId) {
        return vehicleRepository.findById(memberId)
                .orElseThrow(() -> new IllegalStateException("member is not a driver"));
    }

}
